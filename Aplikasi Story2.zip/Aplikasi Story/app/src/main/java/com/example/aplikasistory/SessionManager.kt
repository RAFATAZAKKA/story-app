package com.example.aplikasistory

import android.content.Context
import android.content.SharedPreferences


class SessionManager(context: Context) {

    private var prefs: SharedPreferences =
        context.getSharedPreferences("user_session", Context.MODE_PRIVATE)

    companion object {
        private const val USER_TOKEN = "USER_TOKEN" // Key untuk token
    }

    // Fungsi untuk menyimpan token setelah login berhasil
    fun saveLogin(token: String) {
        prefs.edit().putString(USER_TOKEN, token).apply()
    }

    // Fungsi untuk mendapatkan token yang tersimpan
    fun getToken(): String? {
        return prefs.getString(USER_TOKEN, null)
    }

    // Fungsi untuk mengecek apakah pengguna sudah login
    fun isLoggedIn(): Boolean {
        return getToken() != null
    }

    // Fungsi untuk menghapus session saat logout
    fun clearSession() {
        prefs.edit().clear().apply()
    }
}


//class SessionManager(context: Context) {
//
//    private val sharedPreferences = context.getSharedPreferences("user_session", Context.MODE_PRIVATE)
//
//    fun saveLogin(token: String?) {
//        sharedPreferences.edit()
//            .putBoolean("is_logged_in", true)
//            .putString("auth_token", token)
//            .apply()
//    }
//
//    fun isLoggedIn(): Boolean {
//        return sharedPreferences.getBoolean("is_logged_in", false)
//    }
//
//    fun getToken(): String? {
//        return sharedPreferences.getString("auth_token", null)
//    }
//
//    fun clearSession() {
//        sharedPreferences.edit()
//            .clear()
//            .apply()
//    }
//}

