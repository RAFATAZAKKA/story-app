package com.example.aplikasistory

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sessionManager = SessionManager(this)
        val token = sessionManager.getToken()

        // Periksa apakah token masih ada
        if (!token.isNullOrBlank()) {
            // Jika token valid, buka halaman utama
            startActivity(Intent(this, MainActivity::class.java))
        } else {
            // Jika tidak ada token, buka halaman welcome/login
            startActivity(Intent(this, WelcomeActivity::class.java))
        }
        finish() // Hentikan SplashActivity agar tidak bisa kembali ke sini
    }
}
